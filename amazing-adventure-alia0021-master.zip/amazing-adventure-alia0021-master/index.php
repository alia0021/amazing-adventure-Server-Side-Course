
<?php
/* 
received help from tutor: Mayank
change index.html to index.php
create an array for rooms
create string for description and direction elements for each room except trapped door.
use isset to determine if there is a variable attached to the room
use _get to indicate which room you are in
I created two variables for my description and value.
I ended with else statement to have the game to have the game visible



rooms:
'Room 1',
'Room 2', 
'Room 3',
'Room 4',
'Room 5',
'Room 6',
'Room 7',
'Room 8',
'Room 9',
 */

$rooms = [
  'Room 1' => [
    'desc' => 'You are in room 1.',
    'East' => 'Room 2',
    'South' => 'Room 4'
  ],
  'Room 2' => [
    'desc' => 'You are in room 2.',
    'East' => 'Room 3',
    'South' => 'Room 5'
  ],
  'Room 3' => [
    'desc' => 'You are in room 3.',
    'South' => 'Room 6',
    'West' => 'Room 3'
  ],
  'Room 4' => [
    'desc' => 'You are in room 4.',
    'South' => 'Room 7'
  ],
  'Room 5' => [
    'desc' => 'You are trapped, Game Over.',
    'reset' => 'Room 1'
  ],
  'Room 6' => [
    'desc' => 'You are in room 6.',
    'North' => 'Room 3',
    'West' => 'Room 5'
  ],
  'Room 7' => [
    'desc' => 'You are in room 7.',
    'East' => 'Room 8',
    'North' => 'Room 4'
  ],
  'Room 8' => [
    'desc' => 'You are in room 8.',
    'East' => 'Room 9',
    'North' => 'Room 5'
  ],
  'Room 9' => [
    'desc' => 'You are in room 9.',
    'East' => 'GameWin'
  ],
  'GameWin' => [
    'desc' => 'You won the game.',
    'reset' => 'Room 1'
  ]
]
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>aMAZing Adventures</title>
  <link rel="stylesheet" href="adventure.css">
</head>
<body>
  <?php if (isset($_GET['room'])) { ?>
  <div class="response"><?php echo $rooms[$_GET['room']]['desc']; ?></div>
  <div class="actions">
    <?php foreach ($rooms[$_GET['room']] as $name => $desc) { ?>
    <?php if ($name !== 'desc') { ?>
      <a href="?room=<?php echo $desc; ?>" class="action"><?php echo $name; ?></a>
    <?php 
  } ?>
     <?php 
  } ?>
  </div>
  <?php 
} else { ?> 
    <div class="response"><?php echo $rooms['Room 1']['desc']; ?></div>
    <div class="actions">
    <?php foreach ($rooms['Room 1'] as $name => $desc) { ?>
    <?php if ($name !== 'desc') { ?>
      <a href="?room=<?php echo $desc; ?>" class="action"><?php echo $name; ?></a>
    <?php 
  } ?>
     <?php 
  } ?>
  </div>
     <?php 
  } ?>
</body>
</html>